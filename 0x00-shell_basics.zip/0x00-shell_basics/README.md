 Joel code day 2
